@extends('templetes.tampletesDashboard.User.site')


@section('titulo', 'SALGUEIRO BUSCA RAPIDO: EVENTOS')

@section('eventos', 'active')

@section('conteudo')
<section id="main-content">
<section class="wrapper site-min-height">
<div class="row mt" style="text-align: center">
<div style="width: 100%; height:60px;">
<h1 style="color: #979797;">Ainda não tem eventos</h1>
<hr>
</div>
</div>
<!-- /container -->
</section>
<!-- /wrapper -->
</section>
@endsection