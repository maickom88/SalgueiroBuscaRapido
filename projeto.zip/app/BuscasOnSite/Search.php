<?php

namespace App\BuscasOnSite;

use Illuminate\Database\Eloquent\Model;

class Search extends Model
{
    //
}
