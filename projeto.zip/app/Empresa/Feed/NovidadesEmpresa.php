<?php

namespace App\Empresa\Feed;

use Illuminate\Database\Eloquent\Model;

class NovidadesEmpresa extends Model
{
    //
}
