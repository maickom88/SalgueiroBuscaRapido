<?php

namespace App\Empresa\Album;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    //
}
