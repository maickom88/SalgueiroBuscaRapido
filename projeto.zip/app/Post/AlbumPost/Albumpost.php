<?php

namespace App\Post\AlbumPost;

use Illuminate\Database\Eloquent\Model;

class Albumpost extends Model
{
    //
}
