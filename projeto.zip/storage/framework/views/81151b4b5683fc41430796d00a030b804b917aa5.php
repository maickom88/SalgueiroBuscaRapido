<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $str = $post->title;
    $str2 = str_replace(' ', '-', $str);
    $dataReplace = explode(' ',$post->created_at);
    $data = explode('-', $dataReplace[0]);
?>
<div class="row mt mb" id="search">
    <div class="col-md-4" style="display:flex; align-items:center">
        <span class="custom-checkbox" style="margin-top:0px;">
                <input type="checkbox" class="checkDelete" name="check" value="">
                <label for="checkbox1"></label>
        </span>
        <h4 id="nomeSearch"><?php echo e($post->title); ?></h4>
    </div>
    <div class="col-md-4" style="display:flex; align-items:center">
        <div style="display:flex; align-items:center; margin-right:20px;">
            <h4><?php echo e($post->comments->count()); ?></h4>
            <i style="margin-top:0px;margin-left:10px;font-size:20px;" class="fa fa-comments"></i>
        </div>
        <div style="display:flex; align-items:center; margin-right:20px;">
            <h4><?php echo e($post->views); ?></h4>
            <i style="margin-top:0px;margin-left:10px;font-size:20px;" class="fa fa-eye"></i>
        </div>
        <div style="display:flex; align-items:center; margin-right:20px;">
            <h4><?php echo e($data[2].'/'.$data[1].'/'.$data[0]); ?></h4>
        </div>
    </div>
    <div class="col-md-4" style="display:flex; align-items:center; margin-top:0px;">
        <div style="display:flex; align-items:center; ">
        <a  href=<?php echo e(route('blog.page').'/'.$str2.'/'.$post->id); ?>  class="btn btn-info" style="margin-right:10px;">Visualizar postagem</a>
        <a href=<?php echo e(route('blogUserEdit').'/'.$post->id); ?> class="btn btn-warning" style="margin-right:10px;"><i class="fa fa-edit"></i></a>
        <button onclick='excluirPost(<?php echo e($post->id); ?>)' class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="margin-top:5px">
            <div style="width:100%; height:2px; background:#B7B2B2"></div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row text-center" style="padding:10px;">
<?php if(isset($todas)): ?>

<?php elseif(isset($desativadas)): ?>

<?php else: ?>
<?php echo e($posts->links()); ?>


<div>Mostrando <b><?php echo e($posts->count()); ?></b> de <b> <?php echo e($posts->total()); ?> </b>posts</div>

<?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardUser/paginas/tableUserPosts.blade.php ENDPATH**/ ?>