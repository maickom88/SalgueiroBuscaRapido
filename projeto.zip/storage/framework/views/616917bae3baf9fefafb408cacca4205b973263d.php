
    <div class="container contato-empresa">
        <h4>Última Novidade!</h4>
        <?php $__currentLoopData = $novidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $novidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  <?php
			$avatar = $empresa->logoMarca;
		  ?>
				<div style="margin-bottom:20px; background:url(<?php echo e(asset("../img/bg.png")); ?>); background-size:size; background-repeat:no-repeat; border-radius:5px; padding:10px; box-shadow: 0px 0px 3px rgba(0,0,0,0.2)">
				<div class="container">
					<div class="row">
						<div class="col-md-3 text-center">
							<img src=<?php echo e(asset('storage/logo-empresas/'.$avatar)); ?> style="border-radius: 50%; border: 6px solid #fff" width="120"  alt="">
						</div>
						<div id="conteudo-novidade" class="col-md-9"  style="border-radius: 5px;background:rgba(0,0,0,0.4); color:white;font-size:21px; padding:30px;">
							<?php echo $novidade->content; ?>

						</div>
					</div>

						<div class="page-head">
						<div class="demo-gallery">
						<ul id="lightgallery">
					<?php
						$email = $empresa->permissions->users->email;
						$count = $novidade->photos->count();
					for ($i=0; $i <$count ; $i++):

					?>
					<li  class="visi" data-src=<?php echo e(asset('storage/album-novidades/'.$email.'/'.$novidade->photos[$i]->album)); ?>>
					<a href="">
						<img class="img-responsive" style="width:120px !important; height:120px !important" src=<?php echo e(asset('storage/album-novidades/'.$email.'/'.$novidade->photos[$i]->album)); ?>>
						<div class="demo-gallery-poster">
						<img src="https://sachinchoolur.github.io/lightGallery/static/img/zoom.png">

						</div>
					</a>
					</li>
					<?php
					endfor
					?>

					</ul>
					</div>
					</div>
				</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="col-sm-12" style="display: flex; justify-content:center; align-items:center">
			<?php echo e($novidades->links()); ?>

		</div>
	</div>
	<script>
	$('#lightgallery').lightGallery({
	pager: true
	});

	</script>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/paginaIndividual/pageNovidades.blade.php ENDPATH**/ ?>