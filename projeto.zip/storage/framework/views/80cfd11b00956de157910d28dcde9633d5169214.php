
	<table class="table table-striped table-hover">
		<thead>
			<tr>
			<th>
				<span class="custom-checkbox">
					<input type="checkbox" id="selectAll" onclick="checkAll()">
					<label for="selectAll"></label>
				</span>
			</th>
					<th>Id</th>
					<th>Proprietario</th>
					<th>Nome da empresa</th>
					<th>Descrição</th>
					<th>Whatsaap</th>
					<th>Nicho</th>
					<th>Endereço</th>
					<th>Telefone</th>
					<th>Status</th>
					<th>Ações</th>
			</tr>
		</thead>
		<tbody id="myTable">
			<?php

			$id=0;
			?>
			<?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<tr>
			<td>
				<span class="custom-checkbox">
					<input type="checkbox" class="checkDelete" name="check" value=<?php echo e($empresa->id); ?>>
					<label for="checkbox1"></label>
				</span>
			</td>
					<td><?php echo e($empresa->id); ?></td>
					<td><?php echo e($empresa->permissions->users->email); ?></td>
					<td><?php echo e($empresa->name); ?></td>
					<td id="modalDescricao<?php echo e($id+=1); ?>" data-description="<?php echo e($empresa->description); ?>"><?php echo e(substr($empresa->description, 0, 20).'...'); ?><div style="color:royalblue; cursor:pointer; text-decoration:underline" onclick="pegaId(<?php echo e($id); ?>)">Ver mais</div></td>
					<td><?php echo e($empresa->whatsapp); ?></td>
					<td><?php echo e($empresa->nincho); ?></td>
					<td><?php echo e($empresa->location); ?></td>
					<td><?php echo e($empresa->tel); ?></td>
					<?php if($empresa->status == 'ativa'): ?>
					<td>
					<p style="background: rgb(9, 161, 9);color:#fff; text-align:center; border-radius: 2px; padding: 5px;">Ativo</p>
					</td>
				<?php else: ?>
					<td>
					<p style="background: #FE2E2E;color:#fff; text-align:center; border-radius: 2px; padding: 5px;">Suspenso</p>
					</td>
					<?php endif; ?>

					<td>
						<button onclick="carregarEmpresa(<?php echo e($empresa->id); ?>)" style="background:#FFBF00; padding:2px; border: none; border-radius:4px; "><a href="#editEmployeeModal" class="edit" data-toggle="modal"><i style="color: white !important;" class="fa fa-pencil" data-toggle="tooltip" title="Editar"></i></a></button>
						<button  onclick="excluirEmpPorra(<?php echo e($empresa->id); ?>)" class="delete " style="background:#FE2E2E; color:white; padding:2px; border: none; border-radius:4px; " ><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button>
					</td>
			</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php if(isset($todas)): ?>

<?php elseif(isset($desativadas)): ?>

<?php else: ?>
<?php echo e($empresas->links()); ?>


<div class="clearfix">
		<div class="hint-text">Mostrando <b><?php echo e($empresas->count()); ?></b> de <b> <?php echo e($empresas->total()); ?> </b>empresas</div>
	</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/empresasAll.blade.php ENDPATH**/ ?>