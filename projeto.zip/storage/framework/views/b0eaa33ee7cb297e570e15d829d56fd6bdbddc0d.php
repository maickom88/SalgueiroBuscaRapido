<?php echo $__env->make('templetes.topo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->yieldContent('conteudo'); ?>


<?php echo $__env->make('templetes.rodape', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp\www\projeto\resources\views/templetes/site.blade.php ENDPATH**/ ?>