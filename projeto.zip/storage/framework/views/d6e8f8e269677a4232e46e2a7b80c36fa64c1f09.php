<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href=<?php echo e(asset('css/blog.css')); ?>>
    <link href=<?php echo e(asset('css/blog-single.css')); ?> rel="stylesheet">
	<link rel="stylesheet" href=<?php echo e(asset('css/owl.carousel.min.css')); ?>>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: NOTÍCIAS'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <section class="content-services" style="margin-top:20px !important" >
                    <div class="container text-center" >
                        <a href="http://www.freepik.com">
                        <img  width="700px" class="img-fluid" src=<?php echo e(asset('img/404.png')); ?> alt="">
                        </a>
                        <div>
                            <a class="btn btn-info" href="">Voltar para home</a>
                        </div>
                    </div>
                </div>
            </div>
    </section>

<section class="chamada-usuario-cadastro">
    <div class="container-cadastro">
        <h2>SEJA MEMBRO DA NOSSA COMUNIDADE!</h2>
        <p>Se cadastre no site e tenha as melhores notícias</p>
        <a href=<?php echo e(route('cadastro.site')); ?>>Entrar <i class="fas fa-sign-in-alt"></i></a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/errors/404.blade.php ENDPATH**/ ?>