<table class="table table-striped table-hover">
							  <thead>
									<tr>
								 <th>
									 <span class="custom-checkbox">
										 <input type="checkbox" id="selectAll">
										 <label for="selectAll"></label>
									 </span>
								 </th>
								<th>Id</th>
								<th>Nome</th>
								<th>Email</th>
                                <th>Quantidade de posts</th>
								<th>Status</th>
								<th>Ação</th>
								</tr>
							  	</thead>
							  	<tbody>
								<?php $__currentLoopData = $userPer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
								<td>
									<span class="custom-checkbox">
										<input type="checkbox" id="checkbox1" name="options[]" value="1">
										<label for="checkbox1"></label>
									</span>
								</td>
								<td><?php echo e($user->users->id); ?></td>
								<td><?php echo e($user->users->name); ?></td>
								<td><?php echo e($user->users->email); ?></td>
                                <td><?php echo e($user->users->posts->count()); ?></td>
								<td>
									<p style="background: rgb(9, 161, 9);color:#fff; text-align:center; border-radius: 2px; padding: 5px;">Blogueiro</p>
								</td>
									<td>
										<button onclick="editPartner(<?php echo e($user->users->id); ?>)" id="btnParceria" style="background:#FFBF00; padding:2px; border: none; border-radius:4px; "><i style="color: white !important;" class="fa fa-pencil" data-toggle="tooltip" title="Editar"></i></button>
									</td>
								</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  </tbody>
						 </table>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/parceriaAtivas.blade.php ENDPATH**/ ?>