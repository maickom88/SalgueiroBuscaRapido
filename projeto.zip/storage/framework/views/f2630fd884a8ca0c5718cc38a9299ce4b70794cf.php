<?php $__env->startSection('links'); ?>
    <link href=<?php echo e(asset('css/style-empresa.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/style-contato.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/loader-bouncing.css')); ?> rel="stylesheet">
    <link rel="stylesheet" href=<?php echo e(asset('css/jBox.all.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/eventos.css')); ?>>
    <script data-ad-client="ca-pub-1803332419619783" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <style>
    /*.cabecalho::after{
        background:url(<?php echo e(asset('img/img-04.jpg')); ?>)
    }*/
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: '.$evento->nome_evento); ?>
<?php $__env->startSection('descricao',"<?php echo e($evento->descricao_evento); ?>"); ?>
<?php $__env->startSection('tags', "<?php echo e($evento->tags); ?>"); ?>

<?php $__env->startSection('conteudo'); ?>

<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
    $dataMes = array('01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março', '04'=> 'Abril', '05' => 'Maio', '06' => 'Junho', '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro', '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro');
    $data1 = $evento->inicio_data_evento;
    $data2 = $evento->fim_data_evento;
    $hora1 = $evento->inicio_hora_evento;
    $hora2 = $evento->fim_hora_evento;

    $hora1 = explode(':', $hora1);
    $hora2 = explode(':', $hora2);

    if($data1 == $data2){
        $data1 = explode('/', $data1);
        $mes = $data1[1];
        $mes = $dataMes[$mes];
        $dataIgual = 'true';
    }
    else{
        $data1 = explode('/', $data1);
        $mes1 = $data1[1];
        $mes1 = $dataMes[$mes1];

        $data2 = explode('/', $data2);
        $mes2 = $data2[1];
        $mes2 = $dataMes[$mes2];
    }
    $str = $evento->nome_evento;
$str2 = str_replace(' ', '-', $str);
?>



<section id="header">
    <div class="loader loader-bouncing "></div>
    <div class="cabecalho" >
        <div class="banner-corte">
            <div class="img-banner" style="background:url(<?php echo e(asset('storage/eventos/'.$evento->banner)); ?>)">
            </div>
        </div>
        <div class="banner-center">
            <div class="banner" >
                <img src="<?php echo e(asset('storage/eventos/'.$evento->banner)); ?>" style="width:100%; height:100%" alt="Eventos de salgueiro <?php echo e($evento->nome_evento); ?>">
            </div>
        </div>
    </div>
</section>
<section id="conteudo">
    <div class="container">
        <div class="row">
            <div class="titulo">
                <h2><?php echo e($evento->nome_evento); ?></h2>
                <div class="endereco">
                    <i class="fa fa-location-arrow"></i><?php echo e($evento->endereco); ?><br>
                    <?php if(!empty($dataIgual)): ?>
                    <i class="fa fa-clock-o"></i> <?php echo e($data1[0]); ?> de <?php echo e($mes); ?> de <?php echo e(end($data1)); ?>, <hora><?php echo e($hora1[0]); ?>-<?php echo e($hora2[0]); ?></hora><br>
                    <?php else: ?>
                    <i class="fa fa-clock-o"></i> <?php echo e($data1[0]); ?> de <?php echo e($mes1); ?> de <?php echo e(end($data1)); ?> - <?php echo e($data2[0]); ?> de <?php echo e($mes2); ?> de <?php echo e(end($data2)); ?> , <hora><?php echo e($hora1[0]); ?>h-<?php echo e($hora2[0]); ?>h</hora><br>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="descricao">
    <div class="container">
        <div class="row">
            <div class="descricao">
                <h4>DESCRIÇÃO DO EVENTO</h4>
                <div class="descEvent">
                    <?php echo $evento->descricao_evento; ?>

                </div>
            </div>
        </div>
    </div>
</section>
<section id="organizador">
    <div class="container">
            <h4>SOBRE O ORGANIZADOR</h4>
            <div class="sobre"><?php echo e($evento->nome_org); ?> <br><?php echo e($evento->descricao_org); ?></div>
            <a href="" class="btn btnOrg"><i class="fa fa-envelope-o"></i> FALE COM O ORGNIZADOR</a>
            <h4 style="text-transform:uppercase; margin-top:20px"><?php echo e($evento->nomeclatura); ?></h4>
            <div class="sobre">Evento: <?php echo e($evento->ingresso); ?></div>
    </div>
</section>

<section id="comments">
    <div class="container">
        <h4>COMENTÁRIOS</h4>
        <div class="fb-comments" data-href="http://127.0.0.1:8000/eventos/<?php echo e($str2); ?>_<?php echo e($evento->id); ?>" data-width="" data-numposts="5"></div>
    </div>
</section>

<?php $__env->startSection('script'); ?>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v5.0"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/eventos\eventosIndividual.blade.php ENDPATH**/ ?>