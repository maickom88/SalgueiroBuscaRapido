<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href=<?php echo e(asset('css/blog.css')); ?>>
    <link href=<?php echo e(asset('css/blog-single.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/style-empresa.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/style-empresa.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/style-contato.css')); ?> rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: CONTATO'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="intro-area contato" id="intro">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2 class="title">ANUNCIE COM A GENTE</h2>
            <div class="sub-header">
                <p class="paragrafo">Obtenha mais vendas com nosso serviço!
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-lg-8 text-center">
                <div class="feature-block">
                    <div class="single-feature feature-circule">
                        <div class="circule"></div>
                        <span class="featured-icon"><i class="fa fa-exchange"></i></span>
                        <h3>CUSTOM BLABLA</h3>
                        <p>lorem asir sdjmpoqw osdlask fdfjsdf sdjgfshgd fidsjfgsdifjsdkk   </p>
                    </div>
                    <div class="single-feature">
                        <span class="featured-icon"><i class="fa fa-star-half-o"></i></span>
                        <h3>ROBOTOS TAG</h3>
                        <p>lorem impousaen aidjm poieutt akjdiq eiwehfn jfhdk kdjdjfdfjd</p>
                    </div>
                    <div class="single-feature">
                        <span class="featured-icon"><i class="fa fa-arrows-alt"></i></span>
                        <h3>HE TO USE</h3>
                        <p>lorem impousaen aidjm poieutt akjdiq eiwehfn jfhdk kdjdjfdfjd</p>
                    </div>
                    <div class="single-feature">
                        <span class="featured-icon"><i class="fa fa-cog"></i></span>
                        <h3>JAMAICA</h3>
                        <p>lorem impousaen aidjm poieutt akjdiq eiwehfn jfhdk kdjdjfdfjd</p>
                    </div>
                </div>

            </div>
            <div class="col-sm-4 col-lg-4">
                <div class="feature-mockup">
                    <img src="img/contact.png" class="img-center img-fluid">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="intro-area more " id="intro">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="title">NOSSAS GARANTIAS</h2>
            <div class="sub-header">
                <p class="paragrafo">Veja o que mais!
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-7 mb-4">
                <img src="img/11.png" class="img-fluid">
            </div>
            <div class="col-sm-12 col-md-5">
                <div class="feature-list">
                    <ul>
                        <li>
                            <div class="feature-icon">
                                <i class="fa fa-arrows-alt"></i>
                            </div>
                            <div class="feature-details">
                                <h3>Retina Display</h3>
                                <p>Lorem inpusem served ocla me for didie</p>
                            </div>
                        </li>
                         <li>
                            <div class="feature-icon">
                                <i class="fa fa-cog"></i>
                            </div>
                            <div class="feature-details">
                                <h3>Comeck Tirad</h3>
                                <p>Lorem inpusem served ocla me for didie</p>
                            </div>
                        </li>
                         <li>
                            <div class="feature-icon">
                                <i class="fa fa-mobile"></i>
                            </div>
                            <div class="feature-details">
                                <h3>IOS/android</h3>
                                <p>Lorem inpusem served ocla me for didie</p>
                            </div>
                        </li>
                         <li>
                            <div class="feature-icon">
                                <i class="fa fa-undo"></i>
                            </div>
                            <div class="feature-details">
                                <h3>test over</h3>
                                <p>Lorem inpusem served ocla me for didie</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
</section>

<section id="contato">
    <div class="container contato-empresa">
        <h4>CONTATO</h4>
        <form action="" method="GET" enctype="multipart/form-data">
            
            <div class="mensagem-empresa">
                <div class="tex-input">
                    <label for="nome"><i class="fas fa-user-alt"></i></label>
                    <input type="text"placeholder="Digite seu nome" id="nome" name="nome">
            </div>
            <div class="mensagem-empresa">
                <label for="email"><i class="fas fa-envelope"></i></label>
                <input type="email" placeholder="Digite seu email" id="email" name="email">
            </div>
            <div class="mensagem-empresa">
                <label for="email"><i class="fas fa-phone"></i></label>
                <input type="email" placeholder="Digite seu telefone" id="email" name="email">
            </div>
                <div class="text-area">
                    <textarea id="message" name="message" placeholder="Digite sua mensagem que entraremos em contato..."></textarea>
                </div>
            </div>
            <div class="btn-enviar-comentario">
                <label for="enviar">Enviar<i class="fas fa-paper-plane"></i></label>
                <input type="submit" id="enviar" name="enviar">    
            </div>
        </form>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="js/slick.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projeto\resources\views/contato/contato.blade.php ENDPATH**/ ?>