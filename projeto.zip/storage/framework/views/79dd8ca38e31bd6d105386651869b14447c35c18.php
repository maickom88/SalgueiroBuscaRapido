<?php $__env->startSection('titulo', 'SALGUEIRO BUSCA RAPIDO: NOTICIAS'); ?>

<?php $__env->startSection('noticias', 'active'); ?>

<?php $__env->startSection('conteudo'); ?>
<section id="main-content">
<section class="wrapper site-min-height">
<div class="row mt">
<div class="container" >
<div class="card mb-3">
<div class="imagem text-center">

<img src=<?php echo e(asset("storage/posts-header/".$post->banner)); ?> style="opacity: 0.4"  class="card-img-top" alt="...">
<div class="titulo-post text-center"style="padding:10px;">
<h4 style="position: relative; z-index:2;color: #fff; font-weight: bold"><?php echo e($post->title); ?></h4>
</div>
</div>
<div class="card-body">
<div class="avatar">
    <?php if(!empty($post->user->info)): ?>
        <img src=<?php echo e(asset("storage/avatar/".$post->user->info->avatar)); ?> alt=<?php echo e($post->user->name); ?>>
    <?php else: ?>
        <img src=<?php echo e(asset("img/profilezim.png")); ?> alt="">
    <?php endif; ?>
    </div>
<h5 style="font-size: 15px; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;text-transform: uppercase;color:rgb(78, 78, 78);"class="card-title"><?php echo e($post->user->name); ?></h5>
<p style="color:#c4c4c4">Postou<i class="fa fa-pencil-square"></i></p>
<div class="content">
    <?php
        $description = substr($post->conteudo, 0, 1100);
        $description =  strip_tags($description);
        $dataMes = array('01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março', '04'=> 'Abril', '05' => 'Maio', '06' => 'Junho', '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro', '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro');
        $dataReplace = explode(' ',$post->created_at);
        $data = explode('-', $dataReplace[0]);
        $mes = $data[1];
        $mes = $dataMes[$mes];
        $str = $post->title;
        $str2 = str_replace(' ', '-', $str);

    ?>
<p class="card-text"><?php echo e($description); ?> ...<a href=<?php echo e(route('blog.page').'/'.$str2.'/'.$post->id); ?> >Ler mais</a> </p>
</div>
<hr>
<p class="card-text"><i class="fa fa-calendar"></i><small class="text-muted"><?php echo e(end($data)); ?> de <?php echo e($mes); ?> de <?php echo e($data[0]); ?></small></p>
<p class="card-text"><i class="fa fa-comment"></i><small class="text-muted"><a href="#ss"> Comentar</a></small></p>
<p class="card-text"><i class="fa fa-tag"></i><small class="text-muted"> <a href="#"><?php echo e($post->assunto); ?></a></small></p>
<p class="card-text"><i class="fa fa-eye"></i><small class="text-muted"> <a href="/noticias"> Ver mais notícias</a></small></p>

</div>
</div>
</div>
</section>
<!-- /wrapper -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.tampletesDashboard.businessman.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboard/paginas/noticiasEmp.blade.php ENDPATH**/ ?>