<div class="container">
            <div class="row mb-4">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $str = $post->title;
    $str2 = str_replace(' ', '-', $str);
    ?>

    <div class="col-md-4 card-content">
    <div class="card" style="width: 19rem;">
        <div class="img-card">
            <div class="gradient">
            <img class="card-img-top" height="182px" src=<?php echo e(asset('storage/posts-header/'.$post->banner)); ?> alt="Card image cap">
            </div>
        </div>
        <div class="avatar">
            <?php if(!empty($post->user->info)): ?>
                <?php if(!empty($post->user->info->avatar)): ?>
                    <img src=<?php echo e(asset('storage/avatar/'.$post->user->info->avatar)); ?> alt="">
                <?php else: ?>
                    <img src=<?php echo e(asset('img/profilezim.png')); ?> alt="">
                <?php endif; ?>
            <?php else: ?>
                <img src=<?php echo e(asset('img/profilezim.png')); ?> alt="">
            <?php endif; ?>
        </div>
        <div class="card-body">
        <h5 class="card-title"><a href=<?php echo e(route('blog.page').'/'.$str2.'/'.$post->id); ?> > <?php echo e($post->title); ?></a></h5>
        <?php
            $description = substr($post->conteudo, 0, 200);
            $description =  strip_tags($description);
            $dataMes = array('01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março', '04'=> 'Abril', '05' => 'Maio', '06' => 'Junho', '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro', '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro');
            $dataReplace = explode(' ',$post->created_at);
            $data = explode('-', $dataReplace[0]);
            $mes = $data[1];
            $mes = $dataMes[$mes];
        ?>
        <p class="card-text"><?php echo $description; ?>...</p>
            <a class="lermais" href=<?php echo e(route('blog.page').'/'.$str2.'/'.$post->id); ?>>Ler mais <i class="fas fa-eye"></i></a>
        </div>
        <div class="dropdown-divider"></div>
        <div class="local">
            <span><i class="fas fa-calendar-alt"></i></span> <p><?php echo e(end($data)); ?> de <?php echo e($mes); ?> de <?php echo e($data[0]); ?></p><br><span><i class="fas fa-comments"></i></span><p>Comentarios</p><br><span><i class="fas fa-tags"></i></span><p>Blog</p>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo e($posts->links()); ?>

</div>


</div>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/noticias/noticiasPaginate.blade.php ENDPATH**/ ?>