<table class="table table-striped table-hover">
							<thead>
								<tr>
								<th>
									<span class="custom-checkbox">
										<input type="checkbox" id="selectAll" onclick="checkAll()">
										<label for="selectAll"></label>
									</span>
								</th>
										<th>Id</th>
										<th>Data</th>
										<th>Nome</th>
										<th>Telefone</th>
										<th>Email</th>
										<th>Mensagem</th>
										<th>Excluir</th>
								</tr>
							</thead>
							<tbody id="myTable">
                                <?php
                                     $id=0;
                                ?>
								<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$data = $messenge->created_at;
									$data = explode(' ', $data);
									$dataBr = explode('-', $data[0]);
									$dataBr = $dataBr[2].'/'.$dataBr[1].'/'.$dataBr[0];

								?>

								<tr>
								<td>
									<span class="custom-checkbox">
										<input type="checkbox" class="checkDelete" name="check" value=<?php echo e($messenge->id); ?>>
										<label for="checkbox1"></label>
									</span>
								</td>
										<td><?php echo e($messenge->id); ?></td>
										<td><?php echo e($dataBr); ?></td>
										<td><?php echo e($messenge->name); ?></td>
										<td><?php echo e($messenge->tel); ?></td>
										<td><?php echo e($messenge->email); ?></td>
										<td id="modalDescricao<?php echo e($id+=1); ?>" data-description="<?php echo e($messenge->content); ?>"><?php echo e(substr($messenge->content, 0, 30).'...'); ?><div style="color:royalblue; cursor:pointer; text-decoration:underline" onclick="pegaId(<?php echo e($id); ?>)">Ver mais</div></td>
										<td>

											<button onclick="excluirMensagens(<?php echo e($messenge->id); ?>)" " class="delete " style="background:#FE2E2E; color:white; padding:2px; border: none; border-radius:4px; " ><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button>
										</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>

						</table>
						<?php if(isset($todas)): ?>

						<?php elseif(isset($desativadas)): ?>

						<?php else: ?>
						<?php echo e($contact->links()); ?>


						<div class="clearfix">
							  <div class="hint-text">Mostrando <b><?php echo e($contact->count()); ?></b> de <b> <?php echo e($contact->total()); ?> </b>Mensagens</div>
						 </div>
						<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/contatoTabela.blade.php ENDPATH**/ ?>