<table class="table table-striped table-hover">
	<thead>
		<tr>
		<th>
			<span class="custom-checkbox">
				<input type="checkbox" id="selectAll">
				<label for="selectAll"></label>
			</span>
		</th>
				<th>Id</th>
				<th>Proprietario</th>
				<th>Empresa</th>
				<th>Telefone</th>
				<th>Contrato</th>
				<th>Valor</th>
				<th>Inicio do contrato</th>
				<th>Expiração do contrato</th>
				<th>Status</th>
				<th>Renovação do contrato</th>
		</tr>
	</thead>
	<tbody id="myTable">
        <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $inicio = $contrato->inicio_contrato;
            $inicioData = explode('-', $inicio);
            $fim = $contrato->fim_contrato;
            $fimData = explode('-', $fim);
        ?>
            <tr>
		<td>
			<span class="custom-checkbox">
				<input type="checkbox" class="checkDelete" name="check" value=1>
				<label for="checkbox1"></label>
			</span>
		</td>
            <td><?php echo e($contrato->id); ?></td>
            <td><?php echo e($contrato->empresas->permissions->users->name); ?></td>
            <td><?php echo e($contrato->empresas->name); ?></td>
            <td><?php echo e($contrato->empresas->tel); ?></td>
            <td><?php echo e($contrato->tipo); ?></td>
            <td><?php echo e($contrato->valor); ?> <b>R$</b></td>
            <td><?php echo e($inicioData[2].'/'.$inicioData[1].'/'.$inicioData[0]); ?></td>
            <td><?php echo e($fimData[2].'/'.$fimData[1].'/'.$fimData[0]); ?></td>
            <?php if($contrato->status == 'ativa'): ?>
                <td><span class="btn btn-success">Ativo</span></td>
            <?php else: ?>
                <td><span class="btn btn-danger">Expirado</span></td>
            <?php endif; ?>
            <td>
                <button onclick='updatePermission(<?php echo e($contrato->id); ?>)' class="btn btn-warning bt-sm" ><i class="fa fa-gears" data-toggle="tooltip" title="Renovar"></i></button>
            </td>
		</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php if(isset($todas)): ?>

<?php elseif(isset($desativadas)): ?>

<?php else: ?>
<?php echo e($contratos->links()); ?>


<div class="clearfix">
    <div class="hint-text">Mostrando <b><?php echo e($contratos->count()); ?></b> de <b> <?php echo e($contratos->total()); ?> </b>Contratos</div>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/pagamentosTabela.blade.php ENDPATH**/ ?>