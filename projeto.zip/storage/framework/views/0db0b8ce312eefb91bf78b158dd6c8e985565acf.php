<table class="table table-striped table-hover">
	<thead>
		<tr>
		<th>
			<span class="custom-checkbox">
				<input type="checkbox" id="selectAll" onclick="checkAll()">
				<label for="selectAll"></label>
			</span>
		</th>
            <th>Id</th>
            <th>Autor</th>
            <th>Titulo</th>
            <th>Tags</th>
            <th>Assunto</th>
            <th>Visualizações</th>
            <th>Comentários</th>
            <th>Data do post</th>
            <th class="text-center">Ação</th>
        </tr>
	</thead>
	<tbody id="myTable">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php

        ?>
            <tr>
		<td>
			<span class="custom-checkbox">
				<input type="checkbox" class="checkDelete" name="check" value=<?php echo e($post->id); ?>>
				<label for="checkbox1"></label>
			</span>
		</td>
        <?php
            $str = $post->title;
            $str2 = str_replace(' ', '-', $str);
            $dataMes = array('01' => 'Janeiro', '02' => 'Fevereiro', '03' => 'Março', '04'=> 'Abril', '05' => 'Maio', '06' => 'Junho', '07' => 'Julho', '08' => 'Agosto', '09' => 'Setembro', '10' => 'Outubro', '11' => 'Novembro', '12' => 'Dezembro');
            $dataReplace = explode(' ',$post->created_at);
            $data = explode('-', $dataReplace[0]);
            $mes = $data[1];
            $mes = $dataMes[$mes];
        ?>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->user->name); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->tags); ?></td>
            <td><?php echo e($post->assunto); ?></td>
            <td><?php echo e($post->views); ?></td>
            <td><?php echo e($post->comments->count()); ?></td>
            <td><?php echo e(end($data)); ?> de <?php echo e($mes); ?> de <?php echo e($data[0]); ?></td>
            <td style="display:flex">
                <button onclick='excluirPost(<?php echo e($post->id); ?>)' class="btn btn-danger"><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button>
                <a target="_blank" href=<?php echo e(route('blog.page').'/'.$str2.'/'.$post->id); ?> style="margin-left:5px; color:white" class="btn btn-info">Visualizar</a>
                <a target="_blank" href=<?php echo e(route('blogEdit').'/'.$post->id); ?> style="margin-left:5px; color:white" class="btn btn-warning"  data-toggle="tooltip" title="Editar"><i class="fa fa-edit"></i></a>
            </td>
		</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php if(isset($todas)): ?>

<?php elseif(isset($desativadas)): ?>

<?php else: ?>
<?php echo e($posts->links()); ?>


<div class="clearfix">
    <div class="hint-text">Mostrando <b><?php echo e($posts->count()); ?></b> de <b> <?php echo e($posts->total()); ?> </b>Contratos</div>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/postsPublicadosTable.blade.php ENDPATH**/ ?>