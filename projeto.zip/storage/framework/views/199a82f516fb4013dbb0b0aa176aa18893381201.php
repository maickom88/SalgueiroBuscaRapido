<?php $__env->startSection('titulo', 'SALGUEIRO BUSCA RAPIDO: EVENTOS'); ?>

<?php $__env->startSection('eventos', 'active'); ?>

<?php $__env->startSection('conteudo'); ?>
<section id="main-content">
<section class="wrapper site-min-height">
<div class="row mt" style="text-align: center">
<div style="width: 100%; height:60px;">
<h1 style="color: #979797;">Ainda não tem eventos</h1>
<hr>
</div>
</div>
<!-- /container -->
</section>
<!-- /wrapper -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.tampletesDashboard.User.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardUser/paginas/eventos.blade.php ENDPATH**/ ?>