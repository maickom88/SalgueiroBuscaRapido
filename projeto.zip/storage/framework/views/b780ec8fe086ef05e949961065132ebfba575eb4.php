<div class="container comentarios-empresa">
<h4>Feedback</h4>

<?php if($empresa->comments->count() > 0): ?>
		<?php
			$comments = $empresa->comments;
		?>
		<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
		<div class="block">
		<div class="row">
			<div class="col-md-2">
					<div class="img-comentarios">
						<?php if(!empty($comment->user->info)): ?>
							<?php if(!empty($comment->user->info->avatar)): ?>
								<img src=<?php echo e(asset('storage/avatar/'.$comment->user->info->avatar)); ?> class="img-fluid">	
							<?php else: ?>
								<img src=<?php echo e(asset("img/profilezim.png")); ?> class="img-fluid">
							<?php endif; ?>
						<?php else: ?>
						<img src=<?php echo e(asset("img/profilezim.png")); ?> class="img-fluid">
						<?php endif; ?>
					</div>
			</div>
					<div class="col-md-7">
						<h5><?php echo e($comment->user->name); ?><h5>
					</div>
					<div class="col-md-3">
						<div class="star-comentarios">
						<?php if(!empty($comment->avaliacao)): ?>
							<?php
								$count = $comment->avaliacao;
							for ($i=0; $i <$count ; $i++) { 
								print('<span><i class="fas fa-star"></i></span>');
							}
							?>				
						<?php endif; ?>
						</div>
					</div>  
			<div>
		</div>
		<div class="row">
			<div class="col-md-12 text-center">
					<blockquote>
						<p>"<?php echo e($comment->content); ?>"</p>

		<?php
			$dateTime = $comment->created_at;
			$date = explode(' ', $dateTime);
			$date = explode('-', $date[0]);
		?>
						<div class="calendario-post">
							<span><i class="fas fa-calendar-alt"></i></span><p><?php echo e($date[2].'/'.$date[1].'/'.$date[0]); ?></p>
						</div>
					</blockquote>
			</div>
	</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
	<h3> Ainda não há comentários nessa página, seja o primeiro a comentar! </h3>
	<?php endif; ?>
</div>

<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/paginaIndividual/pageComments.blade.php ENDPATH**/ ?>