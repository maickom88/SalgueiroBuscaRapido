
<table class="table table-striped table-hover">
	<thead>
		<tr>
			<th>
				<span class="custom-checkbox">
					<input type="checkbox" id="selectAll">
					<label for="selectAll"></label>
				</span>
			</th>
			<th>Id</th>
            <th>Usúario</th>
			<th>Autor</th>
			<th>Titulo</th>
			<th>Empresa</th>
			<th>Data de fim de promoção</th>
			<th>Status</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody id="myTable">
        <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
			<td>
				<span class="custom-checkbox">
					<input type="checkbox" class="checkDelete" name="check" value=1>
					<label for="checkbox1"></label>
				</span>
			</td>
			<td><?php echo e($promotion->id); ?></td>
			<td><?php echo e($promotion->empresa->permissions->users->email); ?></td>
			<td><?php echo e($promotion->empresa->permissions->users->name); ?></td>
			<td><?php echo e($promotion->title); ?></td>
			<td><?php echo e($promotion->empresa->name); ?></td>
            <td><?php echo e($promotion->data_fim_promocao); ?></td>
            <td><span class="btn btn-success">Ativo</span></td>
            <td><button class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
		</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
 <?php echo e($promotions->links()); ?>

<div class="clearfix">
		<div class="hint-text">Mostrando <b>4</b> de <b>3</b> Usúarios</div>
</div>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/promocoesTable.blade.php ENDPATH**/ ?>