<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href=<?php echo e(asset('css/slick.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/slick-theme.css')); ?>>
	<link rel="stylesheet" href=<?php echo e(asset('css/jBox.all.css')); ?>>
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
	<title ><?php echo $__env->yieldContent('titulo'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('descricao'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('tags'); ?>">
    <meta name="robots" content="">
    <meta name="revisit-after" content="1 day">
    <meta name="language" content="Portuguese">
    <meta name="generator" content="N/A">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    </head>
    <?php echo $__env->yieldContent('links'); ?>

    <!--font-family: 'Open Sans', sans-serif;
font-family: 'Open Sans Condensed', sans-serif;-->
</head>

<body id="body-header">
<!--Start header-->
<?php echo $__env->yieldContent('menu-top'); ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/templetes/topo.blade.php ENDPATH**/ ?>