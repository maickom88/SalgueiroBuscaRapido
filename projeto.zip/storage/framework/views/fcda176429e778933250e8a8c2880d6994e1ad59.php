<?php $__currentLoopData = $empresasPostAtv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
    $data1 = new DateTime();
    $data2 = $empresa->novidades[0]->created_at;


    $minuto = $data1->diff($data2)->format('%i');
    $minutoInt = intval($minuto);

    $hora = $data1->diff($data2)->format('%h');
    $horaInt = intval($hora);

    $dia = $data1->diff($data2)->format('%d');
    $diaInt = intval($dia);

    $mes = $data1->diff($data2)->format('%m');
    $mesInt = intval($mes);

    $ano = $data1->diff($data2)->format('%Y');
    $anoInt = intval($ano);

    if($minutoInt < 3){
        $minuto = 'Agora mesmo';
    }
    else{
        $minuto = $data1->diff($data2)->format('%i minutos atrás');
    }
    if($horaInt == 1){
        $hora = $data1->diff($data2)->format('%h hora atrás');
    }
    else{
        $hora = $data1->diff($data2)->format('%h horas atrás');
    }
    if($mesInt == 1){
        $mes = $data1->diff($data2)->format('%m mês atrás');
    }
    else{
        $mes = $data1->diff($data2)->format('%m meses atrás');
    }
     if($diaInt == 1){
        $dia = $data1->diff($data2)->format('%d dia atrás');
    }
    else{
        $dia = $data1->diff($data2)->format('%d dias atrás');
    }
    if($anoInt == 1){
        $ano = $data1->diff($data2)->format('%Y ano atrás');
    }
    else{
        $ano = $data1->diff($data2)->format('%Y anos atrás');
    }

    $str = $empresa->name;
    $str2 = str_replace(' ', '-', $str);

?>

<div class="desc">
    <div class="thumb">
        <span class="badge bg-theme"><i class="fa fa-clock-o"></i></span>
    </div>
    <div class="details">
        <p>
        <?php if($horaInt == 0): ?>
            <muted><?php echo e($minuto); ?></muted>
        <?php elseif($diaInt == 0): ?>
            <muted><?php echo e($hora); ?></muted>
        <?php elseif($mesInt == 0): ?>
            <muted><?php echo e($dia); ?></muted>
        <?php elseif($anoInt == 0): ?>
            <muted><?php echo e($mes); ?></muted>
        <?php else: ?>
            <muted><?php echo e($ano); ?></muted>
        <?php endif; ?>
        <br/>
        <a href="empresa/<?php echo e($str2); ?>/<?php echo e($empresa->id); ?>#novidades"><?php echo e($empresa->name); ?></a> Postou uma novidade<br/>
        </p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/atividades/recentes.blade.php ENDPATH**/ ?>