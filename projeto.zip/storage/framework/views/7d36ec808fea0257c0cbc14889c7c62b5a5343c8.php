<table class="table table-striped table-hover">
	<thead>
		<tr>
		<th>
			<span class="custom-checkbox">
				<input type="checkbox" id="selectAll" onclick="checkAll()">
				<label for="selectAll"></label>
			</span>
		</th>
            <th>Id</th>
            <th>Autor do evento</th>
            <th>Nome do evento</th>
            <th>Endereço</th>
            <th>data do evento</th>
            <th>data de término</th>
            <th>data de expiração</th>
            <th>Ação</th>
        </tr>
	</thead>
	<tbody id="myTable">
        <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            date_default_timezone_set("Brazil/East");
            $dataAtual = date("Y/m/d");
            $data = $evento->fim_data_evento;
            $data = explode('/', $data);
            $data = end($data).'/'.$data[1].'/'.$data[0];
            $data = DateTime::createFromFormat('Y/m/d', $data);
            $data->add(new DateInterval('P30D')); // 30 dias
            $fim = $data->format('Y/m/d');
            $fimDate = date("Y/m/d", strtotime($fim));
            $dataBr = explode('/',$fimDate);
            $dateExpirade = strtotime($dataAtual) >= strtotime($fimDate) ? true : false;
        ?>
            <tr>
		<td>
			<span class="custom-checkbox">
				<input type="checkbox" class="checkDelete" name="check" value=<?php echo e($evento->id); ?>>
				<label for="checkbox1"></label>
			</span>
		</td>
        <?php
            $str = $evento->nome_evento;
            $str2 = str_replace(' ', '-', $str);
        ?>
            <td><?php echo e($evento->id); ?></td>
            <td><?php echo e($evento->user->name); ?></td>
            <td><?php echo e($evento->nome_evento); ?></td>
            <td><?php echo e($evento->endereco); ?></td>
            <td><?php echo e($evento->inicio_data_evento); ?></td>
            <td><?php echo e($evento->fim_data_evento); ?></td>
            <td><?php echo e(end($dataBr).'/'.$dataBr[1].'/'.$dataBr[0]); ?> <?php if($dateExpirade): ?> <span style="padding:5px; background:#DF0101; color:white"> Expirado</span></td> <?php endif; ?>
            <td style="display:flex">
                <button onclick='excluirEvento(<?php echo e($evento->id); ?>)' class="btn btn-danger"><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button>
                <a target="_blank" href=<?php echo e(route('eventos').'/'.$str2.'_'.$evento->id); ?> style="margin-left:5px; color:white" class="btn btn-info">Visualizar</a>
            </td>
		</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php if(empty($todas)): ?>
<?php echo e($eventos->links()); ?>

<div class="clearfix">
    <div class="hint-text">Mostrando <b><?php echo e($eventos->count()); ?></b> de <b><?php echo e($eventos->total()); ?></b> Eventos</div>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/eventosTabela.blade.php ENDPATH**/ ?>