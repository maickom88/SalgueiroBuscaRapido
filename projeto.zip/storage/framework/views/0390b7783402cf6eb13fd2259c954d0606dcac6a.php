
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>
                    <span class="custom-checkbox">
                        <input type="checkbox" id="selectAll" onclick="checkAll()">
                        <label for="selectAll"></label>
                    </span>
                </th>
                <th>Id</th>
                <th>Usúario</th>
                <th>Autor</th>
                <th>Titulo</th>
                <th>Empresa</th>
                <th>Data de fim de promoção</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody id="myTable">
            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>
                    <span class="custom-checkbox">
                        <input type="checkbox" class="checkDelete" name="check" value=<?php echo e($promotion->id); ?>>
                        <label for="checkbox1"></label>
                    </span>
                </td>
                <td><?php echo e($promotion->id); ?></td>
                <td><?php echo e($promotion->empresa->permissions->users->email); ?></td>
                <td><?php echo e($promotion->empresa->permissions->users->name); ?></td>
                <td><?php echo e($promotion->title); ?></td>
                <td><?php echo e($promotion->empresa->name); ?></td>
                <td><?php echo e($promotion->data_fim_promocao); ?></td>
                <td>
                    <?php if($promotion->status == 'sim'): ?>
                        <span class="btn btn-success">Ativa</span>
                    <?php else: ?>
                        <span class="btn btn-danger">Expirado</span>
                    <?php endif; ?>
                </td>
                <td><button class="btn btn-danger" onclick="excluirPromocao(<?php echo e($promotion->id); ?>)" " class="delete " ><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button></button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(isset($todas)): ?>

    <?php elseif(isset($desativadas)): ?>

    <?php else: ?>
    <?php echo e($promotions->links()); ?>


    <div class="clearfix">
        <div class="hint-text">Mostrando <b><?php echo e($promotions->count()); ?></b> de <b> <?php echo e($promotions->total()); ?> </b>Contratos</div>
    </div>
    <?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/promocoesTabela.blade.php ENDPATH**/ ?>