
<table class="table table-striped table-hover">
	<thead>
		<tr>
			<th>
				<span class="custom-checkbox">
					<input type="checkbox" id="selectAll" onclick="checkAll()">
					<label for="selectAll"></label>
				</span>
			</th>
			<th>Id</th>
			<th>Nome</th>
			<th>Email</th>
			<th>Permissão</th>
			<th>Usúario desde</th>
			<th>Último sessão</th>
			<th>Endereço</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody id="myTable">
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			if($user->permissions->adm == 'sim'){
				$permission = 'Administrador';
				$color = '#0397D6';
			}
			else if($user->permissions->blogueiro == 'sim' ){
				$permission = 'Blogueiro';
				$color = '#A0D197';
			}
			else if($user->permissions->empresario == 'sim' ){
				$permission = 'Empresarial';
				$color = '#797979';
			}
			else if($user->permissions->user == 'sim' and $user->permissions->blogueiro == 'nao'){
				$permission = 'Usúario';
				$color = '#FCB322';
			}
			$dateHors = $user->created_at;
			$date = explode(' ', $dateHors);
			$date = explode('-', $date[0]);
			$dateCreat = $date[2].'/'.$date[1].'/'.$date[0];
		?>
			<tr>
			<td>
				<span class="custom-checkbox">
					<input type="checkbox" class="checkDelete" name="check" value="<?php echo e($user->id); ?>">
					<label for="checkbox1"></label>
				</span>
			</td>
			<td><?php echo e($user->id); ?></td>
			<td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->email); ?></td>
			<td><button class="btn" style="background:<?php echo e($color); ?>; color:white"><?php echo e($permission); ?></button></td>
			<td><?php echo e($dateCreat); ?></td>
			<td>12/02/2019 - as 18:20</td>
			<?php if(empty(!$user->info)): ?>
				<?php if(empty(!$user->info->endereco)): ?>
					<td><?php echo e($user->info->endereco); ?></td>
				<?php else: ?>
					<td>Localidade indefinida!</td>
				<?php endif; ?>
			<?php else: ?>
			<td>Localidade indefinida!</td>
			<?php endif; ?>
			<td>
				<button onclick='updatePermission(<?php echo $user->id; ?>, "<?php echo e($permission); ?>")' class="delete" style="background:orange; color:white; padding:2px; border: none; border-radius:4px; " ><i class="fa fa-pencil" data-toggle="tooltip" title="Editar Permissão"></i></button>
				<button data-confirm onclick='deleteUser(<?php echo e($user->id); ?>, "<?php echo e($permission); ?>")' class="delete" style="background:#FE2E2E; color:white; padding:2px; border: none; border-radius:4px; " ><i class="fa fa-trash-o" data-toggle="tooltip" title="Excluir"></i></button>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php if(empty($todas)): ?>
<?php echo e($users->links()); ?>


<div class="clearfix">
		<div class="hint-text">Mostrando <b><?php echo e($users->count()); ?></b> de <b><?php echo e($users->total()); ?> </b>Usúarios</div>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboardManenger/usuariosAll.blade.php ENDPATH**/ ?>