<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href=<?php echo e(asset('css/blog.css')); ?>>
    <link href=<?php echo e(asset('css/blog-single.css')); ?> rel="stylesheet">
    <link href=<?php echo e(asset('css/style-empresa.css')); ?> rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: NOTÍCIAS'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog">
    <div class="container-blog text-center">
        
            <h1>ÚLTIMOS POSTs</h1>
        <div class="lis">  
            <a href="#" style="color:#d1d1d1">Home</a>
            <a class="ponto">.</a>
            <a href="#">Blog</a>
        </div>
        
    <div class="lestget">
            <a href="#posts">Ler Postagens</a>
    </div>
    
    </div>
</section>


<section id="posts" class="posts">
        <div class="container">
            <div class="row mb-4"> 
    <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php

       
        $str = $dado->titulo;

        $str2 = str_replace(' ', '-', $str);
                
        
    ?>
  
    <div class="col-md-4 card-content">
    <div class="card" style="width: 19rem;">
        <div class="img-card">
            <div class="gradient">
            <img class="card-img-top" src=<?php echo e(asset($dado->imagensblog)); ?> alt="Card image cap">
            </div>
        </div>
        <div class="avatar">
            <img src=<?php echo e(asset($dado->imagens)); ?> alt="">
        </div>
        <div class="card-body">
        <h5 class="card-title"><a href=<?php echo e(route('blog.page' ,[$dado->titulo])); ?> > <?php echo e($dado->titulo); ?></a></h5>
        <p class="card-text"><?php echo e(substr($dado->artigo, 0, 200)); ?>...</p> 
            <a class="lermais" href=<?php echo e(route('blog.page' ,[$str2, $dado->id ])); ?>>Ler mais <i class="fas fa-eye"></i></a>
        </div>
        <div class="dropdown-divider"></div>
        <div class="local">
            <span><i class="fas fa-calendar-alt"></i></span><p>23 Abril 2019</p><br><span><i class="fas fa-comments"></i></span><p>Comentarios</p><br><span><i class="fas fa-tags"></i></span><p>Blog</p>
        </div>
    </div>    
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
            
        <div class="pagination text-center">
            <div class="voltar">
                <a href="#"><i class="fas fa-chevron-left"></i></a>
            </div>
            <div class="numeracao active">
                <a href="#">1</a>
            </div>
            <div class="numeracao">
                <a href="#">2</a>
            </div>
            <div class="numeracao">
                <a href="#">3</a>
            </div>
            
            <div class="next">
                <a href="#"><i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="search-blog">
                <h3>Buscar no Blog:</h3>
                <form action="" method="">
                    <input type="text"name="search" id="procurar"placeholder="Procurar Post...">
                    <label for="enviar"><i class="fas fa-search"></i></label>
                    <input type="submit" id="enviar">
                </form>
            </div>
        </div>
    </div>
</section>

<section class="chamada-usuario-cadastro">
    <div class="container-cadastro">
        <h2>SEJA MEMBRO DA NOSSA COMUNIDADE!</h2>
        <p>Se cadastre no site e tenha as melhores notícias</p>
        <a href="login.html">Entrar <i class="fas fa-sign-in-alt"></i></a>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\projeto\resources\views/noticias/noticias.blade.php ENDPATH**/ ?>