<?php echo $__env->make('templetes.tampletesDashboard.businessman.topo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->yieldContent('conteudo'); ?>


<?php echo $__env->make('templetes.tampletesDashboard.businessman.rodape', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/templetes/tampletesDashboard/businessman/site.blade.php ENDPATH**/ ?>