<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href=<?php echo e(asset('css/blog.css')); ?>>
    <link href=<?php echo e(asset('css/blog-single.css')); ?> rel="stylesheet">
	<link rel="stylesheet" href=<?php echo e(asset('css/owl.carousel.min.css')); ?>>
    <script data-ad-client="ca-pub-1803332419619783" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: PESQUISA'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <section class="content-services" >
            <?php if($empresas->isNotEmpty()): ?>
            <div class="container">
                <div class="row">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Anuncio busca -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1803332419619783"
     data-ad-slot="7706639363"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                    <div class="col-sm-12 text-center "  style="margin-top:38px;">
                        <h2>Resultado</h2>
                        <div class="sub-header">
                            <p>
                                Esses são os nossos parceiros que oferecem o serviço ideal para o que busca!
                            </p>
                        </div>
                    </div>
                </div>
            <div class="container">
                    <div class="row card-slide">
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 card-content " style="outline:none !important;">
                        <div class="likes">
                            <span><?php echo e($emp->likes->count()); ?> <i class="fas fa-heart"></i></span>
                        </div>
                        <div class="card" style="width: 19rem;">
                            <div class="img-card">
                                <div class="gradient">
                                    <img class="card-img-top" src=<?php echo e(asset('storage/logo-empresas/'.$emp->banner)); ?> alt="Banner da empresa, <?php echo e($emp->name); ?>">
                                </div>
                            </div>
                            <div class="avatar">
                                <img src=<?php echo e(asset('storage/logo-empresas/'.$emp->logoMarca)); ?> alt="Logo marca da empresa, <?php echo e($emp->name); ?>">
                            </div>
                            <div class="tag text-center">
                                <h6 style="text-transform:capitalize"><?php echo e($emp->nincho); ?></h6>
                            </div>
                            <div class="card-body">
                                <?php
                                    $str = $emp->name;
                                    $str2 = str_replace(' ', '-', $str);
                                ?>
                                <h5 class="card-title"><a href="/empresa/<?php echo e($str2); ?>/<?php echo e($emp->id); ?>" ><?php echo e($emp->name); ?></a></h5>
                                <p class="card-text"><?php echo e(substr($emp->description, 0 , 140).'...'); ?><a href="/empresa/<?php echo e($str2); ?>/<?php echo e($emp->id); ?>" style="color:blue;">Ler mais</a></p>
                            </div>
                            <div class="star">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i><span>(<?php echo e($emp->views->views); ?> Visitas)<span>
                            </div>
                            <div class="dropdown-divider"></div>
                            <div class="local">
                                <span><i class="fas fa-map-marker-alt"></i></span><p><?php echo e($emp->location); ?></p>
                            </div>
                        </div>
                    </div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="container text-center" style="margin-top:60px;">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Anuncio busca -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1803332419619783"
     data-ad-slot="7706639363"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                        <a href="http://www.freepik.com">
                        <img  width="700px" class="img-fluid" src=<?php echo e(asset('img/404.png')); ?> alt="">
                        </a>
                        <div>
                            <a class="btn btn-info" href="">Voltar para home</a>
                        </div>
                    </div>
                <?php endif; ?>
                </div>
            </div>
    </section>

<section class="chamada-usuario-cadastro">
    <div class="container-cadastro">
        <h2>SEJA MEMBRO DA NOSSA COMUNIDADE!</h2>
        <p>Se cadastre no site e tenha as melhores notícias</p>
        <a href=<?php echo e(route('cadastro.site')); ?>>Entrar <i class="fas fa-sign-in-alt"></i></a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script src=<?php echo e(asset('js/owl.carousel.min.js')); ?>></script>
	<script src=<?php echo e(asset('js/owl.animate.js')); ?>></script>
	<script src=<?php echo e(asset('js/menu-fixo.js')); ?>></script>
<script>
$(window).on('hashchange', function() {
		if (window.location.hash) {
			var page = window.location.hash.replace('#', '');
			if (page == Number.NaN || page <= 0) {
					return false;
			}else{
					getData(page);
			}
		}
	});

	$(document).ready(function()
	{
		$(document).on('click', '.pagination a',function(event)
		{
			event.preventDefault();

			$('li').removeClass('active');
			$(this).parent('li').addClass('active');

			var myurl = $(this).attr('href');
			var page=$(this).attr('href').split('page=')[1];

			getData(page);
		});

	});

	function getData(page){
		$.ajax(
		{
			url: '../api/evento/eventos?page=' + page,
			type: "get",
			datatype: "html"
		}).done(function(data){
			$("#eventoPaginate").empty().html(data);
			location.hash = page;
		}).fail(function(jqXHR, ajaxOptions, thrownError){
				alert('No response from server');
		});
	}
var owl = $('.owl-carousel');
owl.owlCarousel({
    items:1,
    loop:true,
    margin:10,
    autoplay:true,
    autoplayTimeout:2000,
    autoplayHoverPause:true
});
$('.play').on('click',function(){
    owl.trigger('play.owl.autoplay',[1000])
})
$('.stop').on('click',function(){
    owl.trigger('stop.owl.autoplay')
});

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/busca/buscarSite.blade.php ENDPATH**/ ?>