<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href=<?php echo e(asset('css/blog.css')); ?>>
    <link href=<?php echo e(asset('css/blog-single.css')); ?> rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','SALGUEIRO BUSCA RÁPIDO: NOTÍCIAS'); ?>

<?php $__env->startSection('conteudo'); ?>
<?php echo $__env->make('templetes.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog">
    <div class="container-blog text-center">

            <h1>ÚLTIMOS POSTs</h1>
        <div class="lis">
            <a href="#" style="color:#d1d1d1">Home</a>
            <a class="ponto">.</a>
            <a href="#">Blog</a>
        </div>

    <div class="lestget">
            <a href="#posts">Ler Postagens</a>
    </div>

    </div>
</section>


<section id="posts" class="posts">
    <?php echo $__env->make('noticias.noticiasPaginate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="search-blog">
                <h3>Buscar no Blog:</h3>
                <form action="" method="">
                    <input type="text"name="search" id="procurar"placeholder="Procurar Post...">
                    <label for="enviar"><i class="fas fa-search"></i></label>
                    <input type="submit" id="enviar">
                </form>
            </div>
        </div>
    </div>
</section>

<section class="chamada-usuario-cadastro">
    <div class="container-cadastro">
        <h2>SEJA MEMBRO DA NOSSA COMUNIDADE!</h2>
        <p>Se cadastre no site e tenha as melhores notícias</p>
        <a href=<?php echo e(route('cadastro.site')); ?>>Entrar <i class="fas fa-sign-in-alt"></i></a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src=<?php echo e(asset('js/menu-fixo.js')); ?>></script>
<script>
$(window).on('hashchange', function() {
    if (window.location.hash) {
        var page = window.location.hash.replace('#', '');
        if (page == Number.NaN || page <= 0) {
                return false;
        }else{
                getData(page);
        }
    }
});

$(document).ready(function()
{
    $(document).on('click', '.pagination a',function(event)
    {
        event.preventDefault();

        $('li').removeClass('active');
        $(this).parent('li').addClass('active');

        var myurl = $(this).attr('href');
        var page=$(this).attr('href').split('page=')[1];

        getData(page);
    });

});

function getData(page){
    $.ajax(
    {
        url: '../api/posts?page=' + page,
        type: "get",
        datatype: "html"
    }).done(function(data){
        $("#posts").empty().html(data);
        location.hash = page;
    }).fail(function(jqXHR, ajaxOptions, thrownError){
            alert('No response from server');
    });
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templetes.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/noticias/noticias.blade.php ENDPATH**/ ?>