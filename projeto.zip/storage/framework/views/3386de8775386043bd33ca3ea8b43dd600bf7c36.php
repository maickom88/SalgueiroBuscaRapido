<?php echo $__env->make('templetes.tampletesDashboard.User.topo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->yieldContent('conteudo'); ?>


<?php echo $__env->make('templetes.tampletesDashboard.User.rodape', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/templetes/tampletesDashboard/User/site.blade.php ENDPATH**/ ?>