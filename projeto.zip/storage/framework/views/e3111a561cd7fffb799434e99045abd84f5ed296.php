<?php $__env->startSection('titulo', 'SALGUEIRO BUSCA RAPIDO: PAGAMENTO'); ?>

<?php $__env->startSection('links'); ?>
	<link href=<?php echo e(asset("lib/advanced-datatable/css/demo_table.css")); ?> rel="stylesheet" />
    <link rel="stylesheet" href=<?php echo e(asset("lib/advanced-datatable/css/DT_bootstrap.css")); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagamento', 'active'); ?>

<?php $__env->startSection('conteudo'); ?>
<section id="main-content">
     <?php
        $inicio = $user->empresas->contratos->inicio_contrato;
        $inicioData = explode('-', $inicio);
        $fim = $user->empresas->contratos->fim_contrato;
        $fimData = explode('-', $fim);
    ?>
    <section class="wrapper site-min-height">
        <div class="row mt">
            <div class="container" >
                <h3><i class="fa fa-angle-right"></i>Contratos</h3>
        <div class="row mb">
			<div class="content-panel" style="background:#EAEAEA;">
				<div class="adv-table">
					<table class="table">
						<thead>
							<tr style="background:#4FC1E9; color:white">
								<th scope="col">Inicio do contrato</th>
								<th scope="col">Término do contrato</th>
								<th scope="col">Valor</th>
								<th scope="col">Plano</th>
								<th scope="col">Status</th>
                                <th scope="col">Número para renovação</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo e($inicioData[2].'/'.$inicioData[1].'/'.$inicioData[0]); ?></td>
								<td><?php echo e($fimData[2].'/'.$fimData[1].'/'.$fimData[0]); ?></td>
								<td><?php echo e($user->empresas->contratos->valor); ?></td>
								<td><?php echo e($user->empresas->contratos->tipo); ?></td>
								<?php if($user->empresas->contratos->status == 'ativa'): ?>
                                    <td><span class="btn btn-success">Ativo</span></td>
                                <?php else: ?>
                                    <td><span class="btn btn-danger">Expirado</span></td>
                                <?php endif; ?>
                                <td class="btn btn-info">55+ 87 98838-2558</td>
                            </tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
            </div>
        </div>
    </section>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.tampletesDashboard.businessman.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/login/dashboard/paginas/pagamento.blade.php ENDPATH**/ ?>