<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="Dashboard">
	<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<title><?php echo $__env->yieldContent('titulo'); ?></title>

	<link href=<?php echo e(asset('img/favicon.ico')); ?> rel="icon">
	<link href=<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?> rel="stylesheet">
	<link href=<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?> rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?> />
	<link href=<?php echo e(asset('css/style-painel.css')); ?> rel="stylesheet">
	<link href=<?php echo e(asset('css/style-responsive.css')); ?> rel="stylesheet">
	<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href=<?php echo e(asset('css/style.css')); ?>>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.11/css/lightgallery.css">
	<link rel="stylesheet" href=<?php echo e(asset('css/painel.css')); ?>>
	<link rel="stylesheet" href=<?php echo e(asset('css/loader-bouncing.css')); ?>>
	<link rel="stylesheet" href=<?php echo e(asset('css/jBox.all.css')); ?>>
	<link rel="stylesheet" href=<?php echo e(asset('css/style-empresa.css')); ?>>
	<script src=<?php echo e(asset("lib/chart-master/Chart.js")); ?>></script>
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
	<link href=<?php echo e(asset('css/loader-bouncing.css')); ?> rel="stylesheet">
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
	<?php echo $__env->yieldContent('links'); ?>
</head>

<body>
	<div class="loader loader-bouncing"></div>
<section id="container">
	<header class="header black-bg">
		<div class="sidebar-toggle-box">
			<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
			</div>

			<!--logo start-->
			<a href="/" class="logo"><img src=<?php echo e(asset('img/logofinal1.png')); ?> style="width:120px"alt=""></a>
		<div class="top-menu">
			<ul class="nav pull-right top-menu">
				<li><a class="logout" href=<?php echo e(route('logoutUser')); ?>>Sair <i class="fa fa-sign-out"></i></a></li>
			</ul>
		</div>
	</header>
	<aside>
		<div id="sidebar" class="nav-collapse ">
			<ul class="sidebar-menu" id="nav-accordion">
				<p class="centered"><a href=<?php echo e(route('userPerfil')); ?>>
				<?php if(empty($user->info->avatar)): ?>
                <img src=<?php echo e(asset('img/profilezim.png')); ?> class="img-circle avatar-menu" width="80">
                <?php else: ?>
                <img id="avatar-menu" src="" class="img-circle avatar-menu" width="80">
                <?php endif; ?>
				</a><img>
				<h5 class="centered"><?php echo e(Auth::user()->name); ?></h5>
				<li class="mt">
					<a class="<?php echo $__env->yieldContent('menuPrincipal'); ?>" href=<?php echo e(route('painel')); ?>>
						<i class="fa fa-dashboard"></i>
						<span>Painel Empresarial</span>
					</a>
				</li>
				<li class="sub-menu">
					<a  class="<?php echo $__env->yieldContent('perfil'); ?>" href=<?php echo e(route('perfilEmp')); ?>>
						<i class="fa fa-user"></i>
						<span>Meu perfil</span>
					</a>
				</li>
				<li class="sub-menu">
					<a class="<?php echo $__env->yieldContent('empresa'); ?>" href=<?php echo e(route('editarEmp')); ?>>
						<i class="fa fa-briefcase"></i>
						<span>Minha empresa</span>
					</a>
				</li>
				<li class="sub-menu">
					<a class="<?php echo $__env->yieldContent('pagamento'); ?>" href=<?php echo e(route('pagEmp')); ?>>
						<i class="fa fa-money"></i>
						<span>Tabela de pagamentos</span>
					</a>
				</li>
				<li class="sub-menu">
					<a class="<?php echo $__env->yieldContent('novidade'); ?>"  href=<?php echo e(route('postsEmp')); ?>>
						<i class="fa fa-plus-square"></i>
						<span>Postar Novidades</span>
					</a>
				</li>
				<li class="sub-menu">
					<a class="<?php echo $__env->yieldContent('noticias'); ?>"  href=<?php echo e(route('noticiasEmp')); ?>>
						<i class="fa fa-list-alt"></i>
						<span>Notícias</span>
					</a>
				</li>
				<li class="sub-menu">
					<a class="<?php echo $__env->yieldContent('eventos'); ?>" href=<?php echo e(route('eventEmp')); ?>>
						<i class="fa fa-star"></i>
						<span>Eventos</span>
					</a>
				</li>

			</ul>
		</div>
	</aside>

<?php /**PATH C:\wamp64\www\SITE\projeto\resources\views/templetes/tampletesDashboard/businessman/topo.blade.php ENDPATH**/ ?>