




<section class="footer-empresa">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <img src="img/logofinal1.png">
            </div>
            <div class="col-md-9">
            <span>© Salgueiro Busca Rapido 2018 . Todos os direitos resevados.</span>
            
            </div>
            <div class="col-md-3">
                    <a href=""><i class="fab fa-facebook-square"></i></a>
                    <a href=""><i class="fab fa-instagram"></i></i></a>
                    <a href=""><i class="fab fa-whatsapp-square"></i></a>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->yieldContent('script'); ?>


</body>

</html><?php /**PATH C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\salgueiro-busca-rapido\projeto\resources\views/templetes/rodape.blade.php ENDPATH**/ ?>