<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet"/>
    <title >SALGUEIRO BUSCA RÁPIDO: CADASTRO</title>       
    <link rel="stylesheet" href=<?php echo e(asset('css/style.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(asset('css/cadastro-final.css')); ?>>
</head>

<body>
<div class="marca">
    <a href="pagep.html"><img src="img/logofinal1.png"></a>
</div>
<section class="login">
    <div class="container">
        <div class="login-usuario text-center">
            <div class="avatar-login">
                <div class="avatar-usuario">
                    <i class="fas fa-user"></i>
                </div>
            </div>
            <!--<div class="facebook-logar mb-4">
                <a href="#">Crie conta com facebook</a>
            </div>
            -->
            <form>
                <div class="txtb">
                    <input type="text" id="nome">
                    <label for="nome" id="nome-label">Digite seu nome Completo</label>
                </div>
                
                <div class="txtb">
                    <input type="email" class="email" id="email">
                    <label id="email-label" for="email">Digite seu email</label>
                </div>

                <div class="txtb">
                    <input type="password" class="senha" id="senha">
                    <label id="senha-label" for="senha">Digite sua senha</label>
                </div>
                <div class="txtb">
                    <input type="password" class="senha" id="confsenha">
                    <label id="senha-label-conf" for="confsenha">Confirme sua senha</label>
                </div>
                <div style="font-size:13px;color:red; display:none;" id="alerta">
                    <p >No mínimo 7 caracteres, com ao menos uma letra e um número.</p>
                </div>
                <div style="font-size:13px;color:red; display:none;" id="conf">
                    <p >Senha e confirmar senha não correspodem</p>
                </div>
                <div class="info">
                    <i class="fas fa-info"></i><span> No mínimo 7 caracteres, com ao menos uma letra e um número.</span>
                </div>

                <div class="termos">
                    <input type="checkbox" onclick="mostrarsenha(1)" id="termos"><label>Estou ciente dos <a href="#">Termos de Uso</a> da SBR.</label>
                </div>
                
                <label for="enviar">Continuar</label>
                <input type="submit" id="enviar">
            </form>
            <div class="dropdown-divider"></div>
            
            <span>Possui uma conta?<a href=<?php echo e(route('login.home')); ?>> Clique aqui</a> para entrar.
        </div>
    </div>
</div>
</div>


</section>

<script src="js/typed.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>
<script src="js/slick.min.js"></script>

<script src=<?php echo e(asset('js/js.cadastro.js')); ?>></script>    
</body>
</html><?php /**PATH C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\salgueiro-busca-rapido\projeto\resources\views/cadastro/logar.blade.php ENDPATH**/ ?>